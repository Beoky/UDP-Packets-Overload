# UDP-Flood-with-cpp
UDP Flood attack created with C++ (Confirm can down any device are using 2.4GHz Wifi!)
# Overview
![overview1](https://media.discordapp.net/attachments/879939876181647380/923840786670419988/unknown.png?width=790&height=460)
![overview2](https://media.discordapp.net/attachments/879939876181647380/923840530666889236/unknown.png?width=790&height=460)
# How did work?
UDP Flood will sending MANY OF MANY emoji + unicode to target server!
# Terms of Services
* Using for prank, test only!
# Why created this project?
This just a learn C++ level 2 for me and i gonna making new program from this!
# How to install
* For Linux (x64 only read more in ever testing model.)
Please Download from release first or follow this!
* (linux) download with wget
```
wget https://github.com/PC1266/UDP-Flood-with-cpp/releases/download/1.0/udpflood
chmod +x udpflood
./udpflood
```
Output
```
 pc1266  pc1266-dynabook-Satellite-L40-213Y-HD  ~  Desktop  Devloping  C++  $  wget https://github.com/PC1266/UDP-Flood-with-cpp/releases/download/1.0/udpflood
--2021-12-24 14:44:36--  https://github.com/PC1266/UDP-Flood-with-cpp/releases/download/1.0/udpflood
Resolving github.com (github.com)... 20.205.243.166
Connecting to github.com (github.com)|20.205.243.166|:443... connected.
HTTP request sent, awaiting response... 302 Found
Location: https://objects.githubusercontent.com/github-production-release-asset-2e65be/441377059/60efe498-f974-485d-8a26-eb60aa6c013b?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIWNJYAX4CSVEH53A%2F20211224%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20211224T074437Z&X-Amz-Expires=300&X-Amz-Signature=eef1402417707c47b2de9f94d23a72fe8c0602a9ec3a703796183707696eaac4&X-Amz-SignedHeaders=host&actor_id=0&key_id=0&repo_id=441377059&response-content-disposition=attachment%3B%20filename%3Dudpflood&response-content-type=application%2Foctet-stream [following]
--2021-12-24 14:44:37--  https://objects.githubusercontent.com/github-production-release-asset-2e65be/441377059/60efe498-f974-485d-8a26-eb60aa6c013b?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIWNJYAX4CSVEH53A%2F20211224%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20211224T074437Z&X-Amz-Expires=300&X-Amz-Signature=eef1402417707c47b2de9f94d23a72fe8c0602a9ec3a703796183707696eaac4&X-Amz-SignedHeaders=host&actor_id=0&key_id=0&repo_id=441377059&response-content-disposition=attachment%3B%20filename%3Dudpflood&response-content-type=application%2Foctet-stream
Resolving objects.githubusercontent.com (objects.githubusercontent.com)... 185.199.108.133, 185.199.111.133, 185.199.109.133, ...
Connecting to objects.githubusercontent.com (objects.githubusercontent.com)|185.199.108.133|:443... connected.
HTTP request sent, awaiting response... 200 OK
Length: 203464 (199K) [application/octet-stream]
Saving to: ‘udpflood’

udpflood                        100%[====================================================>] 198.70K  --.-KB/s    in 0.07s   

2021-12-24 14:44:38 (2.92 MB/s) - ‘udpflood’ saved [203464/203464]

 pc1266  pc1266-dynabook-Satellite-L40-213Y-HD  ~  Desktop  Devloping  C++  $  chmod +x udpflood
 pc1266  pc1266-dynabook-Satellite-L40-213Y-HD  ~  Desktop  Devloping  C++  $  ./udpflood
UDP ATTACK BY C++ (First C++ project of PC1266)
If something is error please contect in issues of github.
IP Address: 
```
* (linux) download from website without wget
```
chmod +x udpflood
./udpflood
```
output
```
 pc1266  pc1266-dynabook-Satellite-L40-213Y-HD  ~  Desktop  Devloping  C++  $  chmod +x udpflood
 pc1266  pc1266-dynabook-Satellite-L40-213Y-HD  ~  Desktop  Devloping  C++  $  ./udpflood
UDP ATTACK BY C++ (First C++ project of PC1266)
If something is error please contect in issues of github.
IP Address: 
```
* For Windows
If windows 10 or later using WSL ubuntu for run!
* For Windows 8.1 or older
Using Virutal Machine to run!
* For other OS, arm
clone this project by git clone and run or build from C++ IDE (have many tips in youtube)
# What operating system are working?
| Operating system  | CPU | Result | 
| ------------- | ------------- | ------------- |
| Linux (Ubuntu)| Intel x64  | working |
| Windows (WSL)  | -  | soon |
| Android (termux) | arm64 | Exec format error |
| Android (IDE) | arm64 | working |
* Notice more list will show in soon!

